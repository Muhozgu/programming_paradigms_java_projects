import java.util.UUID;

public class Rent {
    private UUID rentId;
    private Client client;
    private Vehicle vehicle;
    private long startDate; // Use milliseconds for simplicity
    private long endDate;

    public Rent(Client client, Vehicle vehicle, long startDate) {
        this.rentId = UUID.randomUUID();
        this.client = client;
        this.vehicle = vehicle;
        this.startDate = startDate;
        this.endDate = 0;
    }

    public String rentInfo() {
        return "Rent ID: " + rentId +
                ", Start Date: " + startDate +
                ", Number of Rental Days: " + calculateRentalDays() +
                ", End Date: " + endDate +
                ", Client: " + client.getClientInfo() +
                ", Vehicle: " + vehicle.vehicleInfo();
    }

    public int calculateRentalDays() {
        long currentTime = System.currentTimeMillis();
        return (int) Math.ceil((currentTime - startDate) / (24 * 60 * 60 * 1000.0));
    }

    public double rentalCost() {
        return calculateRentalDays() * vehicle.getBaseRentalPrice();
    }

    public void returnVehicle(long endDate) {
        this.endDate = endDate;
    }
}


