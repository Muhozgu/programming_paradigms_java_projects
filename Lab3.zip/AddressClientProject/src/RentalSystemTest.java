import org.junit.Test;

import static org.junit.Assert.*;

public class RentalSystemTest {

    @Test
    public void testUnreturnedVehicleRentalPeriod() {
        // Create a customer
        Address customerAddress = new Address("Main Street", "123");
        Client customer = new Client("John Doe", customerAddress);

        // Create a vehicle
        Vehicle vehicle = new Vehicle(50.0, "ABC123");

        // Create a rental with a specific date (current - 10 days)
        long startDate = System.currentTimeMillis() - (10 * 24 * 60 * 60 * 1000);
        Rent rental = customer.rentVehicle(vehicle, startDate);

        // Check the rental time in days (should be 0)
        assertEquals(0, rental.calculateRentalDays());

        // Check if the customer has this rental
        assertTrue(customer.getCurrentRentals().contains(rental));
    }

    @Test
    public void testReturnedVehicleRentalPeriod() {
        // Create a customer
        Address customerAddress = new Address("Main Street", "123");
        Client customer = new Client("John Doe", customerAddress);

        // Create a vehicle
        Vehicle vehicle = new Vehicle(50.0, "ABC123");

        // Create a rental with a specific date (current - 10 days)
        long startDate = System.currentTimeMillis() - (10 * 24 * 60 * 60 * 1000);
        Rent rental = customer.rentVehicle(vehicle, startDate);

        // Return the vehicle (always with the current date)
        rental.returnVehicle(System.currentTimeMillis());

        // Check the rental time in days (should be different from 0)
        assertNotEquals(0, rental.calculateRentalDays());

        // Check if the customer has this rental
        assertTrue(customer.getCurrentRentals().contains(rental));
    }

    @Test
    public void testVehicleReturnTimeEarlierThanRentalTime() {
        // Create a customer
        Address customerAddress = new Address("Main Street", "123");
        Client customer = new Client("John Doe", customerAddress);

        // Create a vehicle
        Vehicle vehicle = new Vehicle(50.0, "ABC123");

        // Create a rental with a specific date (current - 10 days)
        long startDate = System.currentTimeMillis() - (10 * 24 * 60 * 60 * 1000);
        Rent rental = customer.rentVehicle(vehicle, startDate);

        // Return the vehicle with a date earlier than the rental start date
        rental.returnVehicle(startDate - 1);

        // Check the rental time in days (should be 0)
        assertEquals(0, rental.calculateRentalDays());

        // Check if the customer has this rental
        assertTrue(customer.getCurrentRentals().contains(rental));
    }

    @Test
    public void testCorrectRentalValueCalculation() {
        // Create a customer
        Address customerAddress = new Address("Main Street", "123");
        Client customer = new Client("John Doe", customerAddress);

        // Create a vehicle with a base rental price of $50.0
        Vehicle vehicle = new Vehicle(50.0, "ABC123");

        // Create a rental with a specific date (current - 5 days)
        long startDate = System.currentTimeMillis() - (5 * 24 * 60 * 60 * 1000);
        Rent rental = customer.rentVehicle(vehicle, startDate);

        // Return the vehicle (always with the current date)
        rental.returnVehicle(System.currentTimeMillis());

        // Check if the rental cost is calculated correctly
        double expectedRentalCost = 5 * vehicle.getBaseRentalPrice();
        assertEquals(expectedRentalCost, rental.rentalCost(),0.001);
    }
}
