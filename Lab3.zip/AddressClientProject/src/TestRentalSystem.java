public class TestRentalSystem {
    public static void main(String[] args) {
        // Create a Vehicle
        Address homeAddress = new Address("Main Street", "123");
        Client client1 = new Client("Sania sohail ", homeAddress);
        Vehicle car = new Vehicle(50, "ABC123");

        // Rent a vehicle for a client
        long startDate = System.currentTimeMillis() - (5 * 24 * 60 * 60 * 1000); // 5 days ago
        Rent rental1 = client1.rentVehicle(car, startDate);

        // Display rent information
        System.out.println(rental1.rentInfo());

        // Simulate returning the vehicle
        long endDate = System.currentTimeMillis();
        rental1.returnVehicle(endDate);

        // Display updated rent information
        System.out.println(rental1.rentInfo());
        System.out.println("Rental Cost: $" + rental1.rentalCost());

        // Display client information with rentals
        System.out.println("Client Info: " + client1.getClientInfo());
        System.out.println("Rentals: " + client1.getCurrentRentals());
    }
}
