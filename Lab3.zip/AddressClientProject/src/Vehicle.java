public class Vehicle {
    private double baseRentalPrice;
    private String registrationNumber;

    public Vehicle(double baseRentalPrice, String registrationNumber) {
        this.baseRentalPrice = baseRentalPrice;
        this.registrationNumber = registrationNumber;
    }

    public String vehicleInfo() {
        return "Vehicle: Registration Number - " + registrationNumber +
                ", Base Rental Price - " + baseRentalPrice;
    }

    public double getBaseRentalPrice() {
        return baseRentalPrice;
    }
}

