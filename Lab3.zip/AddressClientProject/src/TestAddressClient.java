public class TestAddressClient {
    public static void main(String[] args) {
        // a. Create an object of the Address class
        Address homeAddress = new Address("Main Street", "123");

        // b. Assign this address as the home address for both clients
        Client client1 = new Client("Sania Sohail", homeAddress);
        Client client2 = new Client("Maryam Sohail", homeAddress);

        // c. List customer data on the console
        System.out.println("Client 1: " + client1.getClientInfo());
        System.out.println("Client 2: " + client2.getClientInfo());

        // d. Modify the created Address class object
        homeAddress = new Address("Broadway", "456");

        // e. List customer data on the console
        System.out.println("Client 1: " + client1.getClientInfo());
        System.out.println("Client 2: " + client2.getClientInfo());

        // f. Compare the addresses of both customers
        if (client1.getHomeAddress().getStreet().equals(client2.getHomeAddress().getStreet())
                && client1.getHomeAddress().getHouseNumber().equals(client2.getHomeAddress().getHouseNumber())) {
            System.out.println("Both clients have the same address.");
        } else {
            System.out.println("Clients have different addresses.");
        }
    }
}
