import java.util.ArrayList;
import java.util.List;

public class Client {
    private String name;
    private Address homeAddress;
    private List<Rent> currentRentals;

    public Client(String name, Address homeAddress) {
        this.name = name;
        this.homeAddress = homeAddress;
        this.currentRentals = new ArrayList<>();
    }

    public Rent rentVehicle(Vehicle vehicle, long startDate) {
        Rent newRental = new Rent(this, vehicle, startDate);
        currentRentals.add(newRental);
        return newRental;
    }

    public String getClientInfo() {
        return "Client: " + name +
                ", Home Address: " + homeAddress.getStreet() + " " + homeAddress.getHouseNumber() +
                ", Current Rentals: " + currentRentals.size();
    }

    public Address getHomeAddress() {
        return homeAddress;
    }

    public List<Rent> getCurrentRentals() {
        return currentRentals;
    }
}



