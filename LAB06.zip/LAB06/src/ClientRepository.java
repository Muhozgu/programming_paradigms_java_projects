import java.util.List;

public class ClientRepository extends Repository<Client>{

    @Override
    public void create() {

    }

    @Override
    public void remove() {

    }

    @Override
    public void update() {

    }

    @Override
    public void delete() {

    }

    @Override
    public List<Client> getAll() {
        return null;
    }

    @Override
    public Client find() {
        return null;
    }
}
