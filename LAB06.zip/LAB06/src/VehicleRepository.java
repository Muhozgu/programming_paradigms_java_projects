import java.util.List;

public class VehicleRepository extends Repository<Vehicle>{

    @Override
    public void create() {

    }

    @Override
    public void remove() {

    }

    @Override
    public void update() {

    }

    @Override
    public void delete() {

    }

    @Override
    public List<Vehicle> getAll() {
        return null;
    }

    @Override
    public Vehicle find() {
        return null;
    }
}
