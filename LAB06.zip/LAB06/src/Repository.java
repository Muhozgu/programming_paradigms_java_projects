import java.util.List;

public abstract class Repository<T> {

    public abstract void create();
    public abstract void remove();
    public abstract void update();
    public abstract void delete();
    public abstract List<T> getAll();
    public abstract T find();

}
