public class Client {
    private int ClientId;
    private  String clientName;


    public Client(){

    }

    public Client(int clientId,String clientName){
        this.ClientId = clientId;
        this.clientName = clientName;
    }
}
