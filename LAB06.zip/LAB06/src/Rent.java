import java.util.Date;

public class Rent {
    private int rentId;
    private Client client;
    private Vehicle vehicle;
    private Date startDate;
    private Date endDate;
    // Other rental-related attributes

    // Constructors, getters, setters, and other methods as needed

    public Rent() {
        // Default constructor
    }

    public Rent(int rentId, Client client, Vehicle vehicle, Date startDate, Date endDate) {
        this.rentId = rentId;
        this.client = client;
        this.vehicle = vehicle;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // Other methods, getters, and setters
}
