import java.util.List;

public class RentsRepository extends Repository<Rent>{

    @Override
    public void create() {

    }

    @Override
    public void remove() {

    }

    @Override
    public void update() {

    }

    @Override
    public void delete() {

    }

    @Override
    public List<Rent> getAll() {
        return null;
    }

    @Override
    public Rent find() {
        return null;
    }
}
