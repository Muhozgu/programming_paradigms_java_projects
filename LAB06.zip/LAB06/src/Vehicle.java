public class Vehicle {
    private int vehicleId;
    private String make;
    private String model;
    private int year;
    // Other vehicle-related attributes

    // Constructors, getters, setters, and other methods as needed

    public Vehicle() {
        // Default constructor
    }

    public Vehicle(int vehicleId, String make, String model, int year) {
        this.vehicleId = vehicleId;
        this.make = make;
        this.model = model;
        this.year = year;
    }

    // Other methods, getters, and setters
}
