
package com.mycompany.mavenproject5;

public class Mavenproject5 {

    public static void main(String[] args) {

        Bicycle bicycle = new Bicycle(10);
        System.out.println("Bicycle Rental Price: " + bicycle.getActualRentalPrice());

        Mope moped = new Mope(20, 1500);
        double engineModifierMoped = moped.calculateEngineModifier();
        double actualRentalPriceMoped = moped.getActualRentalPrice() * engineModifierMoped;
        System.out.println("Moped Rental Price: " + actualRentalPriceMoped);

        Car car = new Car(30, 2500, 'D');
        double engineModifierCar = car.calculateEngineModifier();
        double segmentModifier = car.calculateSegmentModifier();
        double actualRentalPriceCar = car.getActualRentalPrice() * engineModifierCar * segmentModifier;
     System.out.println("Car Rental Price: " + actualRentalPriceCar);
     
    }
}
