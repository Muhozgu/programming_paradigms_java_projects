package com.mycompany.mavenproject5;

public class Mope extends Vehicle {
    private final double engineDisplacement;

    public Mope(double baseRentalPriceMope, double engineDisplacement) {
        super(baseRentalPriceMope);
        this.engineDisplacement = engineDisplacement;
    }

    public double calculateEngineModifier() {
        if (engineDisplacement < 1000) {
            return 1.0;
        } else if (engineDisplacement <= 2000) {
            return 1.0 + 0.5 * (engineDisplacement - 1000) / 1000;
        } else {
            return 1.5;
        }
    }
}
