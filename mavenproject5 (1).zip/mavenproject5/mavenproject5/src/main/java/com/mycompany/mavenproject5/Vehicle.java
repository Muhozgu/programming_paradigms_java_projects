/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject5;

/**
 *
 * @author legso
 */
public class Vehicle {
    private final double baseRentalPrice;

    public Vehicle(double baseRentalPrice) {
        this.baseRentalPrice = baseRentalPrice;
    }

    public double getActualRentalPrice() {
        return baseRentalPrice;
    }
}
