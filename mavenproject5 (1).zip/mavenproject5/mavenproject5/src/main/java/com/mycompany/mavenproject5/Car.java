
package com.mycompany.mavenproject5;


public class Car extends Vehicle {
//    public class Car extends Vehicle {
    private final double engineDisplacement;
    private final char segment;

    public Car(double baseRentalPriceCar, double engineDisplacement, char segment) {
        super(baseRentalPriceCar);
        this.engineDisplacement = engineDisplacement;
        this.segment = segment;
    }

    public double calculateEngineModifier() {
        if (engineDisplacement < 1000) {
            return 1.0;
        } else if (engineDisplacement <= 2000) {
            return 1.0 + 0.5 * (engineDisplacement - 1000) / 1000;
        } else {
            return 1.5;
        }
    }

    public double calculateSegmentModifier() {
        return switch (segment) {
            case 'A' -> 1.0;
            case 'B' -> 1.1;
            case 'C' -> 1.2;
            case 'D' -> 1.3;
            case 'E' -> 1.5;
            default -> 1.0;
        };
    }
}
