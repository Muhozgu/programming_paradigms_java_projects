/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject5;

/**
 *
 * @author legso
 */
public class Bicycle extends Vehicle {
//    public class Bicycle extends Vehicle {
    public Bicycle(double baseRentalPriceBicycle) {
        super(baseRentalPriceBicycle);
    }
}
