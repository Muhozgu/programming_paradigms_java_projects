import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create a client repository
        ClientRepository clientRepository = new ClientRepository();

        // Create clients
        Client client1 = new Client(1, "John", "Doe", ClientType.DEFAULT);
        Client client2 = new Client(2, "Jane", "Smith", ClientType.PREMIUM);

        // Add clients to the repository
        clientRepository.addClient(client1);
        clientRepository.addClient(client2);

        // Create a rents manager
        RentsManager rentsManager = new RentsManager(clientRepository);

        // Specify the client ID
        String clientId = "1";

        // Check if the client exists before attempting to create a rent
        Client client = clientRepository.getClient(clientId);
        if (client != null) {
            // Create a rental
            Rental rental1 = new Rental(101, "Car rental", clientId, 150.0); // Assume a rental price of 150

            try {
                // Try to create a rent
                rentsManager.createRent(rental1);

                // Display client information
                System.out.println("Client " + clientId + " - ID: " + client.getClientId() +
                        ", Type: " + client.getClientType() +
                        ", Balance: " + client.calculateBalance());

                // Display rental information
                System.out.println("Client " + clientId + " Rentals:");
                List<Rental> clientRentals = rentsManager.getAllClientRents(clientId);
                for (Rental rental : clientRentals) {
                    System.out.println("Rental ID: " + rental.getRentalId() +
                            ", Rental Info: " + rental.getRentalInfo() +
                            ", Rental Price: " + rental.getRentalPrice());
                }

                // Return the vehicle
                rentsManager.returnVehicle(rental1);

                // Display updated client information
                System.out.println("Client " + clientId + " - ID: " + client.getClientId() +
                        ", Type: " + client.getClientType() +
                        ", Balance: " + client.calculateBalance());

                // Display archived rentals for client
                System.out.println("Archived Rentals for Client " + clientId + ":");
                List<Rental> archivedRentals = rentsManager.getAllClientRents(clientId);
                for (Rental rental : archivedRentals) {
                    System.out.println("Rental ID: " + rental.getRentalId() +
                            ", Rental Info: " + rental.getRentalInfo() +
                            ", Rental Price: " + rental.getRentalPrice());
                }

                // Change client type based on balance
                rentsManager.changeClientType(clientId);

                // Display updated client information after changing client type
                System.out.println("Client " + clientId + " - ID: " + client.getClientId() +
                        ", Type: " + client.getClientType() +
                        ", Balance: " + client.calculateBalance());
            } catch (RentException | ClientException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } else {
            System.out.println("Error: Client with ID " + clientId + " not found.");
        }
    }
}
