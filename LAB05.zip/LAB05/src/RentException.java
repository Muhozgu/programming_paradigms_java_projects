public class RentException extends RuntimeException {
    public static final String INVALID_RENTAL_MESSAGE = "Invalid rental operation.";

    public RentException(String message) {
        super(message);
    }
}