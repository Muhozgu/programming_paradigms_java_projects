import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import org.junit.Test;

public class RentsManagerTest {

    @Test
    public void testReturnVehicleEarlierThanRentalTime() {
        // Create a client repository
        ClientRepository clientRepository = new ClientRepository();

        // Add a client with ID "Customer1" to the repository
        Client client1 = new Client(1, "John", "Doe", ClientType.DEFAULT);
        clientRepository.addClient(client1);

        // Create a rents manager
        RentsManager rentsManager = new RentsManager(clientRepository);

        // Attempt to create a rental with an earlier return time than rental time
        try {
            Rental rental1 = new Rental(101, "Car rental", "Customer1", 150.0);

            // Ensure that the client with ID "Customer1" exists in the repository before creating the rental
            // Add any necessary logic to initialize clients in your application

            rentsManager.createRent(rental1);

            // This line should not be reached, as an exception should be thrown before it
            assertEquals(true, false); // Fail the test if it reaches this line
        } catch (RentException e) {
            // Check that the exception message contains the expected information
            assertEquals("Invalid rental operation: Client with ID Customer1 not found.", e.getMessage());
        }
    }
}
