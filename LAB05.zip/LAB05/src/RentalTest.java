import org.junit.Test;
import static org.junit.Assert.*;

public class RentalTest {

    @Test
    public void testGetRentalId() {
        // Create a rental
        Rental rental = new Rental(1, "Some rental info", "Customer1", 100.0);

        // Check if the getRentalId() method returns the expected value
        assertEquals(1, rental.getRentalId());
    }

    @Test
    public void testGetRentalInfo() {
        // Create a rental
        Rental rental = new Rental(1, "Some rental info", "Customer1", 100.0);

        // Check if the getRentalInfo() method returns the expected value
        assertEquals("Some rental info", rental.getRentalInfo());
    }

    @Test
    public void testGetCustomer() {
        // Create a rental
        Rental rental = new Rental(1, "Some rental info", "Customer1", 100.0);


        assertEquals("Customer1", rental.getCustomer());
    }

    @Test
    public void testGetRentalPrice() {
        // Create a rental
        Rental rental = new Rental(1, "Some rental info", "Customer1", 100.0);


        assertEquals(100.0, rental.getRentalPrice(), 0.001);
    }
}
