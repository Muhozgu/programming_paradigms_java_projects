public class Rental {
    private int rentalId;
    private String rentalInfo;
    private String customer;
    private double rentalPrice;  // Add a field to store rental price

    public Rental(int rentalId, String rentalInfo, String customer, double rentalPrice) {
        this.rentalId = rentalId;
        this.rentalInfo = rentalInfo;
        this.customer = customer;
        this.rentalPrice = rentalPrice;
    }

    public double getRentalPrice() {
        return rentalPrice;
    }

    public String getCustomer() {
        return customer;
    }

    public int getRentalId() {
        return rentalId;
    }

    public String getRentalInfo() {
        return rentalInfo;
    }

}
