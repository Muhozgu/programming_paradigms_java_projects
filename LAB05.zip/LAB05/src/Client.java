import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Collections;
enum ClientType{

    DEFAULT(1,0.0),
    FIXED(3,0.1),
    PREMIUM(5,0.2),
    VIP(10, 0.3);

    private final int maxAllowedRentals;
    private final double discount;

    ClientType(int maxAllowedRentals , double discount){
        this.maxAllowedRentals = maxAllowedRentals;
        this.discount = discount;
    }

    public int getMaxAllowedRentals(){
        return  maxAllowedRentals;
    }

    public double getDiscount(){
        return discount;
    }
}

public class Client {
    private int clientId;
    private String firstName;
    private String lastName;
    private List<Rental> currentRentals;

    private  ClientType clientType;


    public Client(int clientId , String firstName , String lastName, ClientType clientType){
         this.clientId = clientId;
         this.firstName = firstName;
         this.lastName = lastName;
         this.currentRentals = new ArrayList<>();
         this.clientType = clientType;
    }




    public ClientType getClientType() {
        return clientType;
    }

    public double calculateBalance() {
        double balance = 0;
        for (Rental rental : currentRentals) {
            balance += rental.getRentalPrice();
        }
        return balance;
    }

    public void checkAndUpdateClientType(double rentalPrice) {
        double currentBalance = calculateBalance();

        if (currentBalance >= 0) {
            setClientType(ClientType.DEFAULT);
        } else if (currentBalance < -100) {
            setClientType(ClientType.FIXED);
        } else if (currentBalance < -200) {
            setClientType(ClientType.PREMIUM);
        } else if (currentBalance < -500) {
            setClientType(ClientType.VIP);
        }
    }
    public int getMaxAllowedRentals(){
        return  clientType.getMaxAllowedRentals();
    }

    public double getDiscount(){
        return  clientType.getDiscount();
    }

    public  void addRental(Rental rental){
        this.currentRentals.add(rental);
    }

    public int getClientId() {
        return this.clientId;
    }

    public void setClientType(ClientType clientType) {
        if (clientType == null) {
            throw new ClientException(ClientException.INVALID_CLIENT_TYPE_MESSAGE);
        }
        this.clientType = clientType;
    }

    public Collection<Object> getCurrentRentals() {
        return currentRentals != null ? Collections.singleton(currentRentals) : Collections.emptyList();
    }
}
