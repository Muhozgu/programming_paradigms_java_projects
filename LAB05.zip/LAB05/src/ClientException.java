public class ClientException extends RuntimeException {
    public static final String INVALID_CLIENT_TYPE_MESSAGE = "Invalid client type.";

    public ClientException(String message) {
        super(message);
    }
}