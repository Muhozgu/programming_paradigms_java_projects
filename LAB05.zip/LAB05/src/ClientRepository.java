import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ClientRepository
{
    private List<Client> clients;

    public ClientRepository(){
        this.clients = new ArrayList<>();
    }

    public void addClient(Client client){
        clients.add(client);
    }

    public void removeClient(Client client){
        clients.remove(client);
    }

    public Client getClient(String clientId) {
        for (Client client : clients) {
            if (String.valueOf(client.getClientId()).equals(clientId)) {
                return client;
            }
        }
        return null;
    }



    public void removeClient(int clientId){
        Iterator<Client> iterator = clients.iterator();
        while (iterator.hasNext()){
            Client client = iterator.next();
            if(client.getClientId() == clientId){
                iterator.remove();
                break;
            }
        }
    }

    public void changeClientType(Client client, ClientType newClientType){
        client.setClientType(newClientType);
    }

    public List<Client>getAllClients(){
        return new ArrayList<>(clients);
    }
}
