import java.util.ArrayList;
import java.util.List;

public class RentsManager {
    private List<Rental> currentRents = new ArrayList<>();
    private List<Rental> archiveRents = new ArrayList<>();
    private ClientRepository clientRepository;

    public RentsManager(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    public void createRent(Rental rental) {
        // Check if the rental is available
        if (!isRentalAvailable(rental)) {
            throw new RentException("Invalid rental operation: Rental with ID " + rental.getRentalId() + " is not available.");
        }

        // Check if the client can rent the vehicle
        String clientId = rental.getCustomer();
        Client client = clientRepository.getClient(clientId);

        if (client == null) {
            throw new RentException("Invalid rental operation: Client with ID " + clientId + " not found.");
        }

        int currentRentalsCount = client.getCurrentRentals().size();
        int maxAllowedRentals = client.getMaxAllowedRentals();

        if (currentRentalsCount >= maxAllowedRentals) {
            throw new RentException("Invalid rental operation: Client with ID " + clientId + " cannot rent more vehicles.");
        }

        // Add the rental to current rents and client's rentals
        currentRents.add(rental);
        client.addRental(rental);
    }


    public void returnVehicle(Rental rental) {
        currentRents.remove(rental);
        archiveRents.add(rental);

        Client client = clientRepository.getClient(rental.getCustomer());
        double rentalPrice = calculateRentalPrice(rental);
        double discount = client.getDiscount();
        double discountedRentalPrice = rentalPrice * (1 - discount);
        client.checkAndUpdateClientType(discountedRentalPrice);
    }


    public List<Rental> getAllClientRents(String clientId) {
        List<Rental> clientRents = new ArrayList<>();
        for (Rental rental : archiveRents) {
            if (rental.getCustomer().equals(clientId)) {
                clientRents.add(rental);
            }
        }
        return clientRents;
    }

    public double checkClientRentBalance(String clientId) {
        double balance = 0;
        for (Rental rental : archiveRents) {
            if (rental.getCustomer().equals(clientId)) {
                balance += calculateRentalPrice(rental);
            }
        }
        return balance;
    }

    public void changeClientType(String clientId) {
        Client client = clientRepository.getClient(clientId);
        client.checkAndUpdateClientType(checkClientRentBalance(clientId));
    }

    private boolean isRentalAvailable(Rental rental) {
        return currentRents.stream().noneMatch(existingRental -> existingRental.getRentalId() == rental.getRentalId());
    }

    private boolean canRentVehicle(String clientId) {
        Client client = clientRepository.getClient(clientId);

        if (client != null) {
            // Check if the client has reached the maximum allowed rentals
            int currentRentalsCount = client.getCurrentRentals().size();
            int maxAllowedRentals = client.getMaxAllowedRentals();

            return currentRentalsCount < maxAllowedRentals;
        }

        // If the client is not found, consider it as unable to rent
        return false;
    }




    private double calculateRentalPrice(Rental rental) {
        // You need to provide the logic to calculate the rental price based on rental information.
        // For simplicity, I'm assuming a fixed rental price of 100 for demonstration purposes.
        return 100;
    }


}